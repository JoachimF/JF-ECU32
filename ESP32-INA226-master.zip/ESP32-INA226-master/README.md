Origin : https://github.com/UncleRus/esp-idf-lib  

Library modified to work with an **INA226** and to perform a read of Tension/Current/Power in one shot

