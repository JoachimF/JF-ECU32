typedef struct {
	char url[32];
	char parameter[128];
} URL_t;
